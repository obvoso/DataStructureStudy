#include "arraylist.h"

int	getArrayListLength(ArrayList *pList)
{
	return (pList->currentElementCount);
}
