#include <stdio.h>
#include "linkedlist.h"

int	main(void)
{
	LinkedList	*pList;
	ListNode	element;
	int			index = 0;

	pList = createLinkedList();
	displayLinkedList(pList);
	printf("=======ADD=======\n");
	while (index < 10)
	{
		element.data = index * 2;
		addLLElement(pList, index, element);
		index++;
	}
	displayLinkedList(pList);
	printf("=====REMOVE=======\n");
	removeLLElement(pList, 6);
	displayLinkedList(pList);
	clearLinkedList(pList);
	displayLinkedList(pList);
	return (0);
}
