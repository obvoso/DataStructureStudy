#include "linkedlist.h"

int	getLinkedListLength(LinkedList *pList)
{
	return (pList->currentElementCount);
}
