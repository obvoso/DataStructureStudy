#include "doublylist.h"

int	addPolyNodeLast(LinkedList* pList, float coef, int degree)
{
	int	ret = FALSE, i = 0;

	ListNode node = {0,}; //생성, 초기화?
	node.coef = coef;
	node.degree = degree;

	if (pList != NULL)
	{
		int	length = getLinkedListLength(pList);
		ret = addLLElement(pList, length, node);
	}
	return (ret);
}
static	void initLinkedList(LinkedList *pListA, LinkedList *pListB)
{

		addPolyNodeLast(pListA, 1, 2);
		addPolyNodeLast(pListA, 3, 1);
		addPolyNodeLast(pListA, 2, 0);

		addPolyNodeLast(pListb, 5, 3);
		addPolyNodeLast(pListb, 1, 1);
		addPolyNodeLast(pListb, 3, 0);
}

LinkedList	*addPolyNode(LinkedList *pListA, getLinkedList *pListB)
{
	LinkedList *ret;
	ListNode	*NodeA;
	ListNode	*NodeB;

	NodeA = pListA->headerNode.pLink;
	NodeB = pListA->headerNode.pLink;
	ret = createLinkedList();
	while(NodeA && NodeB)
	{
		if (NodeA->degree > NodeB->degree)
		{
			addPolyNodeLast(ret, NodeA->coef, NodeA->degree);
			NodeA = NodeA->pLink;
		}
		else if (NodeA->degree == NodeB->degree)
		{
			addPolyNodeLast(ret, NodeA->coef + NodeB->coef, NodeA->degree);
			NodeA = NodeA->pLink;
			NodeB = NodeB->pLink;
		}
		else
		{
			addPolyNodeLast(ret, NodeB->coef, NodeB->degree);
			NodeB = NodeB->pLink;
		}
	}
	//남은 노드
	while (NodeA)
	{
		addPolyNodeLast(ret, NodeA->coef, NodeA->degree);
		NodeA = NodeA->pLink;
	}
	while (NodeB)
	{
		addPolyNodeLast(ret, NodeB->coef, NodeB->degree);
		NodeB = NodeB->pLink;
	}
	ret->currentElementCount = getLinkedListLength(ret);
	deleteLinkdList(pListA);
	deleteLinkdList(pListB);
	return (ret);
}

int	main(void)
{
	LinkedList *pListA;
	LinkedList *pListB;
	LinkedList	ret;

	pListA = createLinkedList();
	pListB = createLinkedList();
	initLinkedList(pListA, pListB);
	ret = addPolyNode(pListA, pListB);
}